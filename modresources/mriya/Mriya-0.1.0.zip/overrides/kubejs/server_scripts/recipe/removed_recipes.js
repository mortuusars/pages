const RemovedRecipes = {
    ById: []
}

RemovedRecipes.ById = [
    'spelunkery:gunpowder',
    'spelunkery:filling/portal_fluid',
    'spelunkery:emptying/portal_fluid',
    'spelunkery:mixing/portal_fluid',
    'spelunkery:raw_zinc',
    'spelunkery:raw_zinc_nugget',
    'spelunkery:saltpeter_block',
    'spelunkery:bone_meal',
    'spelunkery:saltpeter_from_block',

    'immersive_aircraft:gyrodyne',

    'salt:gunpowder',
    'supplementaries:soap_clean_upgrade_aquatic_bedroll',
]