// Set pack custom name:
Platform.getInfo('mriya').name = 'mriya'

