// Set pack custom name:
Platform.getInfo('mriya').name = 'Mriya'

